﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerMovement : MonoBehaviour
{
    private float Speed = 100;
    Rigidbody PlayerRigidBody;
    public Text ScoreText;
    public float Score = 0;
    int nextSceneIndex;
    // Start is called before the first frame update
    void Start()
    {
        PlayerRigidBody = GetComponent<Rigidbody>();
        nextSceneIndex = SceneManager.GetActiveScene().buildIndex + 1;
    }

    // Update is called once per frame
    void Update()
    {
        float HorizontalInput = Input.GetAxis("Horizontal");
        float VerticalInput = Input.GetAxis("Vertical");

        Vector3 Moving = new Vector3(HorizontalInput, 0, VerticalInput);
        PlayerRigidBody.AddForce(Moving * Speed * Time.deltaTime);
        if (Score >= 2)
        {
            if (SceneManager.sceneCount > nextSceneIndex)
            {
                SceneManager.LoadScene(nextSceneIndex);
            }
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if(collision.collider.tag == "Coin")
        {
            Score += 1;
            ScoreText.text = "Score : " + Score;
            Destroy(collision.gameObject);
        }
        if(collision.collider.tag == "Hazard")
        {
            Destroy(gameObject);
            SceneManager.LoadScene(3);
        }
    }
}
